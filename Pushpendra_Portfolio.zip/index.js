function scrollTrig() {
  gsap.registerPlugin(ScrollTrigger);

  // Using Locomotive Scroll from Locomotive https://github.com/locomotivemtl/locomotive-scroll

  const locoScroll = new LocomotiveScroll({
    el: document.querySelector("#main"),
    smooth: true,
  });
  // each time Locomotive Scroll updates, tell ScrollTrigger to update too (sync positioning)
  locoScroll.on("scroll", ScrollTrigger.update);

  // tell ScrollTrigger to use these proxy methods for the "#main" element since Locomotive Scroll is hijacking things
  ScrollTrigger.scrollerProxy("#main", {
    scrollTop(value) {
      return arguments.length
        ? locoScroll.scrollTo(value, 0, 0)
        : locoScroll.scroll.instance.scroll.y;
    }, // we don't have to define a scrollLeft because we're only scrolling vertically.
    getBoundingClientRect() {
      return {
        top: 0,
        left: 0,
        width: window.innerWidth,
        height: window.innerHeight,
      };
    },
    // LocomotiveScroll handles things completely differently on mobile devices - it doesn't even transform the container at all! So to get the correct behavior and avoid jitters, we should pin things with position: fixed on mobile. We sense it by checking to see if there's a transform applied to the container (the LocomotiveScroll-controlled element).
    pinType: document.querySelector("#main").style.transform
      ? "transform"
      : "fixed",
  });

  // each time the window updates, we should refresh ScrollTrigger and then update LocomotiveScroll.
  ScrollTrigger.addEventListener("refresh", () => locoScroll.update());

  // after everything is set up, refresh() ScrollTrigger and update LocomotiveScroll because padding may have been added for pinning, etc.
  ScrollTrigger.refresh();
}

function rotatetxt() {
  var rotatetxt = document.querySelector("#rotatetxt");
  var t1 = gsap.timeline();

  rotatetxt.innerHTML = rotatetxt.innerHTML
    .split("")
    .map((char, i) => {
      return `<span style = "transform:rotate(${i * 15}deg)">${char}</span>`;
    })
    .join("");
}
// for text animation
function textanimation() {
  var selecttext = document.querySelectorAll(".animation-text h2");

  // console.log(selecttext);
  selecttext.forEach(function (elm) {
    var allh2s = elm.textContent;
    // console.log(allh2s);
    var clutter = "";
    var spllitedtxt = allh2s.split("");
    // console.log(spllitedtxt);
    spllitedtxt.forEach(function (e) {
      clutter += `<span>${e}</span>`;
    });

    elm.innerHTML = clutter;
  });

  gsap.to(".animation-text h2 span", {
    color: "#fafafa",
    stagger: 1,
    scrollTrigger: {
      trigger: ".animation-text h2",
      scroller: "#main",
      start: "top 40%",
      end: "top -200%",
      scrub: 1.2,
    },
  });
}

function mouseEffect() {
  var mouseeffect = document.querySelector("#mouse_effect");

  document.querySelector("body").addEventListener("mousemove", function (elm) {
    gsap.to("#mouse_effect", {
      x: elm.clientX,
      y: elm.clientY,
    });
  });
}

scrollTrig();
rotatetxt();
textanimation();

mouseEffect();



// loader counter

var counter = document.querySelector("#loader-text h1");


var grow= 0;

setInterval(() => {
  if(grow<=100){

    counter.innerHTML = grow++;
  }
}, 35);


var tl = gsap.timeline();

tl.to("#loader",{
  delay: 0,
  duration : 2,
  opacity : 1,

})

tl.to("#loader",{
  delay: 2,
  y : "-100vh",
  duration : 2,
  opacity : 0,
})




